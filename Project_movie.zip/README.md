# Movie Recommendation System

Educational content-based movie recommender. Uses TF-IDF on genres, keywords, and plot descriptions, then cosine similarity to rank other movies. The small original teaching catalog is included in `movies.csv`; plot descriptions are brief paraphrases created for this demonstration.

## Run

```bash
pip install -r requirements.txt
python recommender.py
```

Enter a title from the printed catalog, then optionally enter a genre filter. To run tests:

```bash
python -m unittest test_recommender.py
```

## Design changes / extensions

This project implements the standard TF-IDF + cosine-similarity educational baseline rather than copying a particular repository. Extensions include combined genre/keyword/description features, word bigrams, optional genre filtering, error handling, a command-line interface, and unit tests.

## Limitations

The sample catalog is tiny and has no user ratings or personalization. Similarity scores are not probabilities or quality ratings. More robust systems need larger licensed datasets, evaluation against held-out interactions, and privacy/fairness checks.

## Sources / credit

- Scikit-learn documentation: https://scikit-learn.org/stable/modules/feature_extraction.html
- Scikit-learn TF-IDF API: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html
- Scikit-learn cosine similarity API: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.pairwise.cosine_similarity.html
- Ricci, Rokach, & Shapira (2022), *Recommender Systems Handbook* (3rd ed.), Springer.

## GitHub

Create a GitHub repository, upload these files, and copy its actual URL into the report. No repository has been created automatically.
